async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getNetworkFingerprint() {
  const output = document.getElementById('output');

  if (!('connection' in navigator)) {
    output.textContent = 'Network Information API is not supported in this browser.';
    return;
  }

  const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;

  const data = {
    effectiveType: connection.effectiveType || 'unknown',
    downlink: connection.downlink || 0,
    rtt: connection.rtt || 0,
    saveData: connection.saveData || false,
    type: connection.type || 'unknown'
  };

  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `Collected Network Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getNetworkFingerprint();
