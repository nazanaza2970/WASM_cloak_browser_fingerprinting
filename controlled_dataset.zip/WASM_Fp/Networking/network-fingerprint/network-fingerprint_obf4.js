
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function getNetworkFingerprint() {
  const output = document.getElementById('output');

  if (!('connection' in navigator)) {
    output.textContent = 'Network Information API is not supported in this browser.';
    return;
  }

  const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;

  const data = {
    effectiveType: connection.effectiveType || 'unknown',
    downlink: connection.downlink || 0,
    rtt: connection.rtt || 0,
    saveData: connection.saveData || false,
    type: connection.type || 'unknown'
  };

  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `Collected Network Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getNetworkFingerprint();
