
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function timeFetch(url, importance) {
  const start = performance.now();
  try {
    await fetch(url, {
      importance, // 'high', 'low', or 'auto'
      cache: 'no-store'
    });
  } catch (e) {
    // still return timing to fingerprint failures
  }
  const end = performance.now();
  return +(end - start).toFixed(3); // Keep micro-diff precision
}

async function timeXHR(url) {
  const start = performance.now();
  return new Promise(resolve => {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url + "?xhr=" + Math.random(), true);
    xhr.onreadystatechange = () => {
      if (xhr.readyState === 4) {
        const end = performance.now();
        resolve(+(end - start).toFixed(3));
      }
    };
    xhr.onerror = () => resolve(+(performance.now() - start).toFixed(3));
    xhr.send();
  });
}

async function getFetchTimingFingerprint() {
  const output = document.getElementById('output');
  const url = '../asset/tiny.txt'; // Use a small static file on same origin

  const results = {
    fetch_high: await timeFetch(url, 'high'),
    fetch_auto: await timeFetch(url, 'auto'),
    fetch_low: await timeFetch(url, 'low'),
    xhr: await timeXHR(url)
  };

  const serialized = JSON.stringify(results);
  const hash = await hashString(serialized);

  output.textContent =
    `Fetch/XHR Timing:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getFetchTimingFingerprint();
