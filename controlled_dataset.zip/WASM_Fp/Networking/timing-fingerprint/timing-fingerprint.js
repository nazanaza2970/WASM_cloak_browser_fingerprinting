async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function simplifyEntry(entry) {
  const keys = [
    'name', 'initiatorType', 'startTime', 'duration',
    'fetchStart', 'domainLookupStart', 'domainLookupEnd',
    'connectStart', 'connectEnd', 'requestStart',
    'responseStart', 'responseEnd', 'transferSize', 'encodedBodySize'
  ];
  const out = {};
  for (const k of keys) {
    if (k in entry) out[k] = entry[k];
  }
  return out;
}

async function getTimingFingerprint() {
  const output = document.getElementById('output');

  // Wait for full page load + resource collection
  await new Promise(resolve => {
    if (document.readyState === "complete") resolve();
    else window.addEventListener("load", resolve);
  });

  const navEntries = performance.getEntriesByType("navigation").map(simplifyEntry);
  const resEntries = performance.getEntriesByType("resource")
    .filter(r => r.initiatorType !== "xmlhttprequest" && r.initiatorType !== "fetch")
    .slice(0, 10) // Limit to top 10 to keep hash stable
    .map(simplifyEntry);

  const data = {
    navigation: navEntries,
    resources: resEntries
  };

  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `Collected Timing Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getTimingFingerprint();
