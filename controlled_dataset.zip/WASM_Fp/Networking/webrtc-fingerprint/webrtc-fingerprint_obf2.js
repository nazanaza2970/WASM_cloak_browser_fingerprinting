
let loadWasm = (async function (){
    let wasmBinary_lit = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 4, 5, 1, 112, 1, 1, 1, 5, 3, 1, 0, 1, 6, 44, 7, 127, 0, 65, 32, 11, 127, 0, 65, 192, 0, 11, 127, 0, 65, 224, 0, 11, 127, 0, 65, 128, 1, 11, 127, 0, 65, 140, 1, 11, 127, 1, 65, 140, 129, 2, 11, 127, 0, 65, 140, 129, 2, 11, 7, 52, 5, 8, 99, 118, 49, 95, 112, 111, 107, 97, 3, 0, 8, 99, 118, 50, 95, 112, 111, 107, 97, 3, 1, 7, 115, 99, 49, 95, 112, 111, 105, 3, 2, 7, 115, 99, 50, 95, 112, 111, 105, 3, 3, 6, 109, 101, 109, 111, 114, 121, 2, 0, 9, 6, 1, 0, 65, 1, 11, 0, 12, 1, 4, 11, 151, 1, 4, 0, 65, 12, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 99, 0, 97, 0, 110, 0, 0, 0, 0, 0, 0, 0, 0, 65, 44, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 118, 0, 97, 0, 115, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 0, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 115, 0, 99, 0, 114, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 0, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 101, 0, 101, 0, 110, 0, 0, 0, 0, 0, 0, 0]);
    const imports =  {env: {
    memory: new WebAssembly.Memory({ initial: 64 }), // Adjust memory size as needed
    __alloc: function (size) {
      // Allocate memory and return a pointer (adjust this function as needed for your runtime)
      return memory_lit.grow(Math.ceil((size + memory_lit.buffer.byteLength) / 65536)) || 0;
    },
    store: function (ptr, value) {
      // Store a value at a memory pointer
      let memoryView = new Int32Array(memory_lit.buffer);
      memoryView[ptr / 4] = value; // Assuming 32-bit integers
    },
    abort: function () {
      console.error("Abort called");
      throw new Error("Abort called");
    },
  },
 };       
    let obj_lit = await WebAssembly.instantiate(wasmBinary_lit,imports); //need to add proper env for func, if-else, loops
    let instance_lit = obj_lit.instance;
    let memory_lit = instance_lit.exports.memory;

    return [instance_lit,memory_lit];
    })();


    loadWasm.then((results)=>{
    let [instance_lit, memory_lit] = results;
    function getString(ptr) {
      let len = new Uint32Array(memory_lit.buffer, ptr - 4, 1)[0];
      let strBuffer = new Uint8Array(memory_lit.buffer, ptr, len);
      let str = '';
      for (let i = 0; i < len; i++) {
        let charCode = strBuffer[i];
        if (charCode !== 0) {  // Skip null characters (if any)
          str += String.fromCharCode(charCode);}
      }
      return str;}

     // Note on Privacy & Availability

 //    Local IP leaks via WebRTC are mostly patched in modern browsers unless media.peerconnection.enabled is manually re-enabled (Firefox) or Chrome’s privacy settings allow it.

 //    Still, ICE candidate gathering can expose public IPs, relay use, transport type, and browser behavior, which are fingerprintable.

async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getWebRTCFingerprint() {
  const output = document.getElementById('output');

  const candidates = new Set();

  const pc = new RTCPeerConnection({
    iceServers: []
  });

  // Create a bogus data channel
  pc.createDataChannel("fingerprint");

  pc.onicecandidate = (event) => {
    if (event.candidate) {
      candidates.add(event.candidate.candidate);
    }
  };

  try {
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    // Wait for ICE candidates to be gathered
    await new Promise(resolve => setTimeout(resolve, 1000));
    pc.close();

    const candidateArray = Array.from(candidates).sort(); // Sorted for deterministic hash
    const serialized = JSON.stringify(candidateArray);
    const hash = await hashString(serialized);

    output.textContent =
      `WebRTC ICE Candidates:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
  } catch (err) {
    output.textContent = `WebRTC error: ${err.message}`;
  }
}

getWebRTCFingerprint();

    });
    