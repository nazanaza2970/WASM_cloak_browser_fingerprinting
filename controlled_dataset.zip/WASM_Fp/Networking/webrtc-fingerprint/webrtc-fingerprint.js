 // Note on Privacy & Availability

 //    Local IP leaks via WebRTC are mostly patched in modern browsers unless media.peerconnection.enabled is manually re-enabled (Firefox) or Chrome’s privacy settings allow it.

 //    Still, ICE candidate gathering can expose public IPs, relay use, transport type, and browser behavior, which are fingerprintable.

async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getWebRTCFingerprint() {
  const output = document.getElementById('output');

  const candidates = new Set();

  const pc = new RTCPeerConnection({
    iceServers: []
  });

  // Create a bogus data channel
  pc.createDataChannel("fingerprint");

  pc.onicecandidate = (event) => {
    if (event.candidate) {
      candidates.add(event.candidate.candidate);
    }
  };

  try {
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    // Wait for ICE candidates to be gathered
    await new Promise(resolve => setTimeout(resolve, 1000));
    pc.close();

    const candidateArray = Array.from(candidates).sort(); // Sorted for deterministic hash
    const serialized = JSON.stringify(candidateArray);
    const hash = await hashString(serialized);

    output.textContent =
      `WebRTC ICE Candidates:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
  } catch (err) {
    output.textContent = `WebRTC error: ${err.message}`;
  }
}

getWebRTCFingerprint();
