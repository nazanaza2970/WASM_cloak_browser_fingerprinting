async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function getSimplifiedTiming(timing) {
  const keys = [
    "navigationStart", "unloadEventStart", "unloadEventEnd",
    "redirectStart", "redirectEnd", "fetchStart",
    "domainLookupStart", "domainLookupEnd",
    "connectStart", "connectEnd",
    "requestStart", "responseStart", "responseEnd",
    "domLoading", "domInteractive", "domContentLoadedEventStart",
    "domContentLoadedEventEnd", "domComplete",
    "loadEventStart", "loadEventEnd"
  ];
  const result = {};
  for (const key of keys) {
    if (key in timing) result[key] = timing[key];
  }
  return result;
}

async function getPerformanceFingerprint() {
  const output = document.getElementById('output');

  const nowSample = [];
  for (let i = 0; i < 10; i++) {
    nowSample.push(+performance.now().toFixed(5));
  }

  const timingData = getSimplifiedTiming(performance.timing);

  const data = {
    nowSample,
    timingData
  };

  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `Performance Data:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getPerformanceFingerprint();
