
let loadWasm = (async function (){
    let wasmBinary_lit = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 4, 5, 1, 112, 1, 1, 1, 5, 3, 1, 0, 1, 6, 188, 1, 31, 127, 0, 65, 32, 11, 127, 0, 65, 192, 0, 11, 127, 0, 65, 224, 0, 11, 127, 0, 65, 128, 1, 11, 127, 0, 65, 160, 1, 11, 127, 0, 65, 192, 1, 11, 127, 0, 65, 224, 1, 11, 127, 0, 65, 128, 2, 11, 127, 0, 65, 160, 2, 11, 127, 0, 65, 192, 2, 11, 127, 0, 65, 224, 2, 11, 127, 0, 65, 128, 3, 11, 127, 0, 65, 160, 3, 11, 127, 0, 65, 192, 3, 11, 127, 0, 65, 224, 3, 11, 127, 0, 65, 144, 4, 11, 127, 0, 65, 192, 4, 11, 127, 0, 65, 224, 4, 11, 127, 0, 65, 128, 5, 11, 127, 0, 65, 160, 5, 11, 127, 0, 65, 192, 5, 11, 127, 0, 65, 224, 5, 11, 127, 0, 65, 128, 6, 11, 127, 0, 65, 160, 6, 11, 127, 0, 65, 192, 6, 11, 127, 0, 65, 224, 6, 11, 127, 0, 65, 128, 7, 11, 127, 0, 65, 160, 7, 11, 127, 0, 65, 172, 7, 11, 127, 1, 65, 172, 135, 2, 11, 127, 0, 65, 172, 135, 2, 11, 7, 230, 2, 29, 9, 118, 97, 114, 95, 49, 53, 48, 95, 49, 3, 0, 9, 118, 97, 114, 95, 49, 53, 48, 95, 50, 3, 1, 9, 118, 97, 114, 95, 49, 52, 51, 95, 49, 3, 2, 9, 118, 97, 114, 95, 49, 52, 51, 95, 50, 3, 3, 9, 118, 97, 114, 95, 50, 48, 49, 95, 49, 3, 4, 9, 118, 97, 114, 95, 50, 48, 49, 95, 50, 3, 5, 9, 118, 97, 114, 95, 50, 57, 54, 95, 49, 3, 6, 9, 118, 97, 114, 95, 50, 57, 54, 95, 50, 3, 7, 9, 118, 97, 114, 95, 50, 55, 56, 95, 49, 3, 8, 9, 118, 97, 114, 95, 50, 55, 56, 95, 50, 3, 9, 9, 118, 97, 114, 95, 50, 54, 53, 95, 49, 3, 10, 9, 118, 97, 114, 95, 50, 54, 53, 95, 50, 3, 11, 9, 118, 97, 114, 95, 50, 53, 52, 95, 49, 3, 12, 9, 118, 97, 114, 95, 50, 53, 52, 95, 50, 3, 13, 9, 118, 97, 114, 95, 57, 53, 53, 95, 49, 3, 14, 9, 118, 97, 114, 95, 57, 53, 53, 95, 50, 3, 15, 10, 118, 97, 114, 95, 49, 48, 55, 55, 95, 49, 3, 16, 10, 118, 97, 114, 95, 49, 48, 55, 55, 95, 50, 3, 17, 10, 118, 97, 114, 95, 49, 48, 55, 49, 95, 49, 3, 18, 10, 118, 97, 114, 95, 49, 48, 55, 49, 95, 50, 3, 19, 10, 118, 97, 114, 95, 49, 48, 53, 51, 95, 49, 3, 20, 10, 118, 97, 114, 95, 49, 48, 53, 51, 95, 50, 3, 21, 10, 118, 97, 114, 95, 49, 49, 52, 56, 95, 49, 3, 22, 10, 118, 97, 114, 95, 49, 49, 52, 56, 95, 50, 3, 23, 10, 118, 97, 114, 95, 49, 50, 51, 55, 95, 49, 3, 24, 10, 118, 97, 114, 95, 49, 50, 51, 55, 95, 50, 3, 25, 10, 118, 97, 114, 95, 49, 51, 48, 57, 95, 49, 3, 26, 10, 118, 97, 114, 95, 49, 51, 48, 57, 95, 50, 3, 27, 6, 109, 101, 109, 111, 114, 121, 2, 0, 9, 6, 1, 0, 65, 1, 11, 0, 12, 1, 28, 11, 199, 8, 28, 0, 65, 12, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 100, 0, 105, 0, 103, 0, 0, 0, 0, 0, 0, 0, 0, 65, 44, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 101, 0, 115, 0, 116, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 0, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 115, 0, 117, 0, 98, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 0, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 116, 0, 108, 0, 101, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 102, 0, 114, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 111, 0, 109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 106, 0, 111, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 105, 0, 110, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 112, 0, 97, 0, 100, 0, 83, 0, 0, 0, 0, 0, 0, 65, 172, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 116, 0, 97, 0, 114, 0, 116, 0, 0, 0, 0, 0, 0, 65, 204, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 116, 0, 111, 0, 83, 0, 116, 0, 0, 0, 0, 0, 0, 65, 236, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 114, 0, 105, 0, 110, 0, 103, 0, 0, 0, 0, 0, 0, 65, 140, 3, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 3, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 97, 0, 112, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 3, 11, 48, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 14, 0, 0, 0, 103, 0, 101, 0, 116, 0, 69, 0, 108, 0, 101, 0, 109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 252, 3, 11, 48, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 14, 0, 0, 0, 101, 0, 110, 0, 116, 0, 66, 0, 121, 0, 73, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 4, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 116, 0, 111, 0, 70, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 4, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 105, 0, 120, 0, 101, 0, 100, 0, 0, 0, 0, 0, 0, 65, 236, 4, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 110, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 5, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 111, 0, 119, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 5, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 112, 0, 117, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 5, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 115, 0, 104, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 5, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 116, 0, 105, 0, 109, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 6, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 105, 0, 110, 0, 103, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 6, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 115, 0, 116, 0, 114, 0, 105, 0, 0, 0, 0, 0, 0, 65, 204, 6, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 10, 0, 0, 0, 110, 0, 103, 0, 105, 0, 102, 0, 121, 0, 0, 0, 0, 65, 236, 6, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 10, 0, 0, 0, 116, 0, 101, 0, 120, 0, 116, 0, 67, 0, 0, 0, 0, 65, 140, 7, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 12, 0, 0, 0, 111, 0, 110, 0, 116, 0, 101, 0, 110, 0, 116, 0]);
    const imports =  {env: {
    memory: new WebAssembly.Memory({ initial: 64 }), // Adjust memory size as needed
    __alloc: function (size) {
      // Allocate memory and return a pointer (adjust this function as needed for your runtime)
      return memory_lit.grow(Math.ceil((size + memory_lit.buffer.byteLength) / 65536)) || 0;
    },
    store: function (ptr, value) {
      // Store a value at a memory pointer
      let memoryView = new Int32Array(memory_lit.buffer);
      memoryView[ptr / 4] = value; // Assuming 32-bit integers
    },
    abort: function () {
      console.error("Abort called");
      throw new Error("Abort called");
    },
  },
 };       
    let obj_lit = await WebAssembly.instantiate(wasmBinary_lit,imports); //need to add proper env for func, if-else, loops
    let instance = obj_lit.instance;
    let memory_lit = instance.exports.memory;

    return [instance,memory_lit];
    })();


    loadWasm.then((results)=>{
    let [instance, memory_lit] = results;
    function getString(ptr) {
      let len = new Uint32Array(memory_lit.buffer, ptr - 4, 1)[0];
      let strBuffer = new Uint8Array(memory_lit.buffer, ptr, len);
      let str = '';
      for (let i = 0; i < len; i++) {
        let charCode = strBuffer[i];
        if (charCode !== 0) {  // Skip null characters (if any)
          str += String.fromCharCode(charCode);}
      }
      return str;}

    async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto[getString(instance.exports.var_143_1)+getString(instance.exports.var_143_2)][getString(instance.exports.var_150_1)+getString(instance.exports.var_150_2)]('SHA-256', data);
  const hashArray = Array[getString(instance.exports.var_201_1)+getString(instance.exports.var_201_2)](new Uint8Array(hashBuffer));
  return hashArray[getString(instance.exports.var_254_1)+getString(instance.exports.var_254_2)](b => b[getString(instance.exports.var_265_1)+getString(instance.exports.var_265_2)](16)[getString(instance.exports.var_278_1)+getString(instance.exports.var_278_2)](2, '0'))[getString(instance.exports.var_296_1)+getString(instance.exports.var_296_2)]('');
}

function getSimplifiedTiming(timing) {
  const keys = [
    "navigationStart", "unloadEventStart", "unloadEventEnd",
    "redirectStart", "redirectEnd", "fetchStart",
    "domainLookupStart", "domainLookupEnd",
    "connectStart", "connectEnd",
    "requestStart", "responseStart", "responseEnd",
    "domLoading", "domInteractive", "domContentLoadedEventStart",
    "domContentLoadedEventEnd", "domComplete",
    "loadEventStart", "loadEventEnd"
  ];
  const result = {};
  for (const key of keys) {
    if (key in timing) result[key] = timing[key];
  }
  return result;
}

async function getPerformanceFingerprint() {
  const output = document[getString(instance.exports.var_955_1)+getString(instance.exports.var_955_2)]('output');

  const nowSample = [];
  for (let i = 0; i < 10; i++) {
    nowSample[getString(instance.exports.var_1053_1)+getString(instance.exports.var_1053_2)](+performance[getString(instance.exports.var_1071_1)+getString(instance.exports.var_1071_2)]()[getString(instance.exports.var_1077_1)+getString(instance.exports.var_1077_2)](5));
  }

  const timingData = getSimplifiedTiming(performance[getString(instance.exports.var_1148_1)+getString(instance.exports.var_1148_2)]);

  const data = {
    nowSample,
    timingData
  };

  const serialized = JSON[getString(instance.exports.var_1237_1)+getString(instance.exports.var_1237_2)](data);
  const hash = await hashString(serialized);

  output[getString(instance.exports.var_1309_1)+getString(instance.exports.var_1309_2)] =
    `Performance Data:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getPerformanceFingerprint();

    });
    