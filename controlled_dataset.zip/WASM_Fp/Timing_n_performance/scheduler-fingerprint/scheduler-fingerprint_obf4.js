
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function measurePostTaskDelays() {
  if (!window.scheduler || !scheduler.postTask) return { supported: false };

  const delays = [];
  for (let i = 0; i < 5; i++) {
    const t1 = performance.now();
    await scheduler.postTask(() => {
      const t2 = performance.now();
      delays.push(+(t2 - t1).toFixed(5));
    });
  }
  return { supported: true, delays };
}

function measureIdleCallbackDelays() {
  return new Promise(resolve => {
    if (!window.requestIdleCallback) {
      return resolve({ supported: false });
    }

    const delays = [];
    let count = 0;

    function loop() {
      const t1 = performance.now();
      requestIdleCallback(deadline => {
        const t2 = performance.now();
        delays.push(+(t2 - t1).toFixed(5));
        if (++count < 5) loop();
        else resolve({ supported: true, delays });
      });
    }

    loop();
  });
}

async function getSchedulerFingerprint() {
  const output = document.getElementById('output');

  const postTaskResult = await measurePostTaskDelays();
  const idleCallbackResult = await measureIdleCallbackDelays();

  const data = {
    schedulerPostTask: postTaskResult,
    requestIdleCallback: idleCallbackResult
  };

  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `Scheduler Timing Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getSchedulerFingerprint();
