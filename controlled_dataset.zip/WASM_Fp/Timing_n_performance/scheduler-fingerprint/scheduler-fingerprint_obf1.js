
let loadWasm = (async function (){
    let wasmBinary_lit = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 4, 5, 1, 112, 1, 1, 1, 5, 3, 1, 0, 1, 6, 156, 2, 47, 127, 0, 65, 32, 11, 127, 0, 65, 192, 0, 11, 127, 0, 65, 224, 0, 11, 127, 0, 65, 128, 1, 11, 127, 0, 65, 160, 1, 11, 127, 0, 65, 192, 1, 11, 127, 0, 65, 224, 1, 11, 127, 0, 65, 128, 2, 11, 127, 0, 65, 160, 2, 11, 127, 0, 65, 192, 2, 11, 127, 0, 65, 224, 2, 11, 127, 0, 65, 128, 3, 11, 127, 0, 65, 160, 3, 11, 127, 0, 65, 192, 3, 11, 127, 0, 65, 224, 3, 11, 127, 0, 65, 128, 4, 11, 127, 0, 65, 160, 4, 11, 127, 0, 65, 192, 4, 11, 127, 0, 65, 224, 4, 11, 127, 0, 65, 128, 5, 11, 127, 0, 65, 224, 4, 11, 127, 0, 65, 128, 5, 11, 127, 0, 65, 160, 5, 11, 127, 0, 65, 192, 5, 11, 127, 0, 65, 224, 5, 11, 127, 0, 65, 128, 6, 11, 127, 0, 65, 160, 4, 11, 127, 0, 65, 192, 4, 11, 127, 0, 65, 160, 6, 11, 127, 0, 65, 208, 6, 11, 127, 0, 65, 224, 4, 11, 127, 0, 65, 128, 5, 11, 127, 0, 65, 224, 4, 11, 127, 0, 65, 128, 5, 11, 127, 0, 65, 160, 5, 11, 127, 0, 65, 192, 5, 11, 127, 0, 65, 224, 5, 11, 127, 0, 65, 128, 6, 11, 127, 0, 65, 128, 7, 11, 127, 0, 65, 176, 7, 11, 127, 0, 65, 224, 7, 11, 127, 0, 65, 128, 8, 11, 127, 0, 65, 160, 8, 11, 127, 0, 65, 192, 8, 11, 127, 0, 65, 204, 8, 11, 127, 1, 65, 204, 136, 2, 11, 127, 0, 65, 204, 136, 2, 11, 7, 166, 4, 45, 9, 118, 97, 114, 95, 49, 53, 48, 95, 49, 3, 0, 9, 118, 97, 114, 95, 49, 53, 48, 95, 50, 3, 1, 9, 118, 97, 114, 95, 49, 52, 51, 95, 49, 3, 2, 9, 118, 97, 114, 95, 49, 52, 51, 95, 50, 3, 3, 9, 118, 97, 114, 95, 50, 48, 49, 95, 49, 3, 4, 9, 118, 97, 114, 95, 50, 48, 49, 95, 50, 3, 5, 9, 118, 97, 114, 95, 50, 57, 54, 95, 49, 3, 6, 9, 118, 97, 114, 95, 50, 57, 54, 95, 50, 3, 7, 9, 118, 97, 114, 95, 50, 55, 56, 95, 49, 3, 8, 9, 118, 97, 114, 95, 50, 55, 56, 95, 50, 3, 9, 9, 118, 97, 114, 95, 50, 54, 53, 95, 49, 3, 10, 9, 118, 97, 114, 95, 50, 54, 53, 95, 50, 3, 11, 9, 118, 97, 114, 95, 50, 53, 52, 95, 49, 3, 12, 9, 118, 97, 114, 95, 50, 53, 52, 95, 50, 3, 13, 9, 118, 97, 114, 95, 51, 54, 52, 95, 49, 3, 14, 9, 118, 97, 114, 95, 51, 54, 52, 95, 50, 3, 15, 9, 118, 97, 114, 95, 51, 56, 56, 95, 49, 3, 16, 9, 118, 97, 114, 95, 51, 56, 56, 95, 50, 3, 17, 9, 118, 97, 114, 95, 53, 48, 56, 95, 49, 3, 18, 9, 118, 97, 114, 95, 53, 48, 56, 95, 50, 3, 19, 9, 118, 97, 114, 95, 53, 56, 49, 95, 49, 3, 20, 9, 118, 97, 114, 95, 53, 56, 49, 95, 50, 3, 21, 9, 118, 97, 114, 95, 54, 49, 55, 95, 49, 3, 22, 9, 118, 97, 114, 95, 54, 49, 55, 95, 50, 3, 23, 9, 118, 97, 114, 95, 54, 48, 49, 95, 49, 3, 24, 9, 118, 97, 114, 95, 54, 48, 49, 95, 50, 3, 25, 9, 118, 97, 114, 95, 53, 51, 53, 95, 49, 3, 26, 9, 118, 97, 114, 95, 53, 51, 53, 95, 50, 3, 27, 9, 118, 97, 114, 95, 55, 55, 50, 95, 49, 3, 28, 9, 118, 97, 114, 95, 55, 55, 50, 95, 50, 3, 29, 9, 118, 97, 114, 95, 57, 52, 48, 95, 49, 3, 30, 9, 118, 97, 114, 95, 57, 52, 48, 95, 50, 3, 31, 10, 118, 97, 114, 95, 49, 48, 49, 56, 95, 49, 3, 32, 10, 118, 97, 114, 95, 49, 48, 49, 56, 95, 50, 3, 33, 10, 118, 97, 114, 95, 49, 48, 53, 54, 95, 49, 3, 34, 10, 118, 97, 114, 95, 49, 48, 53, 54, 95, 50, 3, 35, 10, 118, 97, 114, 95, 49, 48, 52, 48, 95, 49, 3, 36, 10, 118, 97, 114, 95, 49, 48, 52, 48, 95, 50, 3, 37, 10, 118, 97, 114, 95, 49, 50, 54, 48, 95, 49, 3, 38, 10, 118, 97, 114, 95, 49, 50, 54, 48, 95, 50, 3, 39, 10, 118, 97, 114, 95, 49, 53, 52, 48, 95, 49, 3, 40, 10, 118, 97, 114, 95, 49, 53, 52, 48, 95, 50, 3, 41, 10, 118, 97, 114, 95, 49, 54, 49, 50, 95, 49, 3, 42, 10, 118, 97, 114, 95, 49, 54, 49, 50, 95, 50, 3, 43, 6, 109, 101, 109, 111, 114, 121, 2, 0, 9, 6, 1, 0, 65, 1, 11, 0, 12, 1, 32, 11, 255, 9, 32, 0, 65, 12, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 100, 0, 105, 0, 103, 0, 0, 0, 0, 0, 0, 0, 0, 65, 44, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 101, 0, 115, 0, 116, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 0, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 115, 0, 117, 0, 98, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 0, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 116, 0, 108, 0, 101, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 102, 0, 114, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 111, 0, 109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 106, 0, 111, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 105, 0, 110, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 112, 0, 97, 0, 100, 0, 83, 0, 0, 0, 0, 0, 0, 65, 172, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 116, 0, 97, 0, 114, 0, 116, 0, 0, 0, 0, 0, 0, 65, 204, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 116, 0, 111, 0, 83, 0, 116, 0, 0, 0, 0, 0, 0, 65, 236, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 114, 0, 105, 0, 110, 0, 103, 0, 0, 0, 0, 0, 0, 65, 140, 3, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 3, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 97, 0, 112, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 3, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 115, 0, 99, 0, 104, 0, 101, 0, 0, 0, 0, 0, 0, 65, 236, 3, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 10, 0, 0, 0, 100, 0, 117, 0, 108, 0, 101, 0, 114, 0, 0, 0, 0, 65, 140, 4, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 112, 0, 111, 0, 115, 0, 116, 0, 0, 0, 0, 0, 0, 65, 172, 4, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 84, 0, 97, 0, 115, 0, 107, 0, 0, 0, 0, 0, 0, 65, 204, 4, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 110, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 4, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 111, 0, 119, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 5, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 116, 0, 111, 0, 70, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 5, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 105, 0, 120, 0, 101, 0, 100, 0, 0, 0, 0, 0, 0, 65, 204, 5, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 112, 0, 117, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 5, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 115, 0, 104, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 6, 11, 48, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 18, 0, 0, 0, 114, 0, 101, 0, 113, 0, 117, 0, 101, 0, 115, 0, 116, 0, 73, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 188, 6, 11, 48, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 20, 0, 0, 0, 108, 0, 101, 0, 67, 0, 97, 0, 108, 0, 108, 0, 98, 0, 97, 0, 99, 0, 107, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 6, 11, 48, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 14, 0, 0, 0, 103, 0, 101, 0, 116, 0, 69, 0, 108, 0, 101, 0, 109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 156, 7, 11, 48, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 14, 0, 0, 0, 101, 0, 110, 0, 116, 0, 66, 0, 121, 0, 73, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 7, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 115, 0, 116, 0, 114, 0, 105, 0, 0, 0, 0, 0, 0, 65, 236, 7, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 10, 0, 0, 0, 110, 0, 103, 0, 105, 0, 102, 0, 121, 0, 0, 0, 0, 65, 140, 8, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 10, 0, 0, 0, 116, 0, 101, 0, 120, 0, 116, 0, 67, 0, 0, 0, 0, 65, 172, 8, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 12, 0, 0, 0, 111, 0, 110, 0, 116, 0, 101, 0, 110, 0, 116, 0]);
    const imports =  {env: {
    memory: new WebAssembly.Memory({ initial: 64 }), // Adjust memory size as needed
    __alloc: function (size) {
      // Allocate memory and return a pointer (adjust this function as needed for your runtime)
      return memory_lit.grow(Math.ceil((size + memory_lit.buffer.byteLength) / 65536)) || 0;
    },
    store: function (ptr, value) {
      // Store a value at a memory pointer
      let memoryView = new Int32Array(memory_lit.buffer);
      memoryView[ptr / 4] = value; // Assuming 32-bit integers
    },
    abort: function () {
      console.error("Abort called");
      throw new Error("Abort called");
    },
  },
 };       
    let obj_lit = await WebAssembly.instantiate(wasmBinary_lit,imports); //need to add proper env for func, if-else, loops
    let instance = obj_lit.instance;
    let memory_lit = instance.exports.memory;

    return [instance,memory_lit];
    })();


    loadWasm.then((results)=>{
    let [instance, memory_lit] = results;
    function getString(ptr) {
      let len = new Uint32Array(memory_lit.buffer, ptr - 4, 1)[0];
      let strBuffer = new Uint8Array(memory_lit.buffer, ptr, len);
      let str = '';
      for (let i = 0; i < len; i++) {
        let charCode = strBuffer[i];
        if (charCode !== 0) {  // Skip null characters (if any)
          str += String.fromCharCode(charCode);}
      }
      return str;}

    async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto[getString(instance.exports.var_143_1)+getString(instance.exports.var_143_2)][getString(instance.exports.var_150_1)+getString(instance.exports.var_150_2)]('SHA-256', data);
  const hashArray = Array[getString(instance.exports.var_201_1)+getString(instance.exports.var_201_2)](new Uint8Array(hashBuffer));
  return hashArray[getString(instance.exports.var_254_1)+getString(instance.exports.var_254_2)](b => b[getString(instance.exports.var_265_1)+getString(instance.exports.var_265_2)](16)[getString(instance.exports.var_278_1)+getString(instance.exports.var_278_2)](2, '0'))[getString(instance.exports.var_296_1)+getString(instance.exports.var_296_2)]('');
}

async function measurePostTaskDelays() {
  if (!window[getString(instance.exports.var_364_1)+getString(instance.exports.var_364_2)] || !scheduler[getString(instance.exports.var_388_1)+getString(instance.exports.var_388_2)]) return { supported: false };

  const delays = [];
  for (let i = 0; i < 5; i++) {
    const t1 = performance[getString(instance.exports.var_508_1)+getString(instance.exports.var_508_2)]();
    await scheduler[getString(instance.exports.var_535_1)+getString(instance.exports.var_535_2)](() => {
      const t2 = performance[getString(instance.exports.var_581_1)+getString(instance.exports.var_581_2)]();
      delays[getString(instance.exports.var_601_1)+getString(instance.exports.var_601_2)](+(t2 - t1)[getString(instance.exports.var_617_1)+getString(instance.exports.var_617_2)](5));
    });
  }
  return { supported: true, delays };
}

function measureIdleCallbackDelays() {
  return new Promise(resolve => {
    if (!window[getString(instance.exports.var_772_1)+getString(instance.exports.var_772_2)]) {
      return resolve({ supported: false });
    }

    const delays = [];
    let count = 0;

    function loop() {
      const t1 = performance[getString(instance.exports.var_940_1)+getString(instance.exports.var_940_2)]();
      requestIdleCallback(deadline => {
        const t2 = performance[getString(instance.exports.var_1018_1)+getString(instance.exports.var_1018_2)]();
        delays[getString(instance.exports.var_1040_1)+getString(instance.exports.var_1040_2)](+(t2 - t1)[getString(instance.exports.var_1056_1)+getString(instance.exports.var_1056_2)](5));
        if (++count < 5) loop();
        else resolve({ supported: true, delays });
      });
    }

    loop();
  });
}

async function getSchedulerFingerprint() {
  const output = document[getString(instance.exports.var_1260_1)+getString(instance.exports.var_1260_2)]('output');

  const postTaskResult = await measurePostTaskDelays();
  const idleCallbackResult = await measureIdleCallbackDelays();

  const data = {
    schedulerPostTask: postTaskResult,
    requestIdleCallback: idleCallbackResult
  };

  const serialized = JSON[getString(instance.exports.var_1540_1)+getString(instance.exports.var_1540_2)](data);
  const hash = await hashString(serialized);

  output[getString(instance.exports.var_1612_1)+getString(instance.exports.var_1612_2)] =
    `Scheduler Timing Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getSchedulerFingerprint();

    });
    