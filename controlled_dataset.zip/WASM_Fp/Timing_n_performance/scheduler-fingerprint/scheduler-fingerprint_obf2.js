
let loadWasm = (async function (){
    let wasmBinary_lit = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 4, 5, 1, 112, 1, 1, 1, 5, 3, 1, 0, 1, 6, 44, 7, 127, 0, 65, 32, 11, 127, 0, 65, 192, 0, 11, 127, 0, 65, 224, 0, 11, 127, 0, 65, 128, 1, 11, 127, 0, 65, 140, 1, 11, 127, 1, 65, 140, 129, 2, 11, 127, 0, 65, 140, 129, 2, 11, 7, 52, 5, 8, 99, 118, 49, 95, 112, 111, 107, 97, 3, 0, 8, 99, 118, 50, 95, 112, 111, 107, 97, 3, 1, 7, 115, 99, 49, 95, 112, 111, 105, 3, 2, 7, 115, 99, 50, 95, 112, 111, 105, 3, 3, 6, 109, 101, 109, 111, 114, 121, 2, 0, 9, 6, 1, 0, 65, 1, 11, 0, 12, 1, 4, 11, 151, 1, 4, 0, 65, 12, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 99, 0, 97, 0, 110, 0, 0, 0, 0, 0, 0, 0, 0, 65, 44, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 118, 0, 97, 0, 115, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 0, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 115, 0, 99, 0, 114, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 0, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 101, 0, 101, 0, 110, 0, 0, 0, 0, 0, 0, 0]);
    const imports =  {env: {
    memory: new WebAssembly.Memory({ initial: 64 }), // Adjust memory size as needed
    __alloc: function (size) {
      // Allocate memory and return a pointer (adjust this function as needed for your runtime)
      return memory_lit.grow(Math.ceil((size + memory_lit.buffer.byteLength) / 65536)) || 0;
    },
    store: function (ptr, value) {
      // Store a value at a memory pointer
      let memoryView = new Int32Array(memory_lit.buffer);
      memoryView[ptr / 4] = value; // Assuming 32-bit integers
    },
    abort: function () {
      console.error("Abort called");
      throw new Error("Abort called");
    },
  },
 };       
    let obj_lit = await WebAssembly.instantiate(wasmBinary_lit,imports); //need to add proper env for func, if-else, loops
    let instance_lit = obj_lit.instance;
    let memory_lit = instance_lit.exports.memory;

    return [instance_lit,memory_lit];
    })();


    loadWasm.then((results)=>{
    let [instance_lit, memory_lit] = results;
    function getString(ptr) {
      let len = new Uint32Array(memory_lit.buffer, ptr - 4, 1)[0];
      let strBuffer = new Uint8Array(memory_lit.buffer, ptr, len);
      let str = '';
      for (let i = 0; i < len; i++) {
        let charCode = strBuffer[i];
        if (charCode !== 0) {  // Skip null characters (if any)
          str += String.fromCharCode(charCode);}
      }
      return str;}

    async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function measurePostTaskDelays() {
  if (!window.scheduler || !scheduler.postTask) return { supported: false };

  const delays = [];
  for (let i = 0; i < 5; i++) {
    const t1 = performance.now();
    await scheduler.postTask(() => {
      const t2 = performance.now();
      delays.push(+(t2 - t1).toFixed(5));
    });
  }
  return { supported: true, delays };
}

function measureIdleCallbackDelays() {
  return new Promise(resolve => {
    if (!window.requestIdleCallback) {
      return resolve({ supported: false });
    }

    const delays = [];
    let count = 0;

    function loop() {
      const t1 = performance.now();
      requestIdleCallback(deadline => {
        const t2 = performance.now();
        delays.push(+(t2 - t1).toFixed(5));
        if (++count < 5) loop();
        else resolve({ supported: true, delays });
      });
    }

    loop();
  });
}

async function getSchedulerFingerprint() {
  const output = document.getElementById('output');

  const postTaskResult = await measurePostTaskDelays();
  const idleCallbackResult = await measureIdleCallbackDelays();

  const data = {
    schedulerPostTask: postTaskResult,
    requestIdleCallback: idleCallbackResult
  };

  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `Scheduler Timing Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getSchedulerFingerprint();

    });
    