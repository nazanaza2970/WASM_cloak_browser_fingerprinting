async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function collectUserTimingMeasurements() {
  // Create some marks
  performance.mark('start');

  // Simulate a blocking loop to create variability
  const delay = 50000; // CPU cycles
  let dummy = 0;
  for (let i = 0; i < delay; i++) {
    dummy += Math.sqrt(i) * Math.sin(i); // simple work
  }

  performance.mark('middle');

  for (let i = 0; i < delay; i++) {
    dummy += Math.sqrt(i) * Math.cos(i);
  }

  performance.mark('end');

  // Create measurements
  performance.measure('start-to-middle', 'start', 'middle');
  performance.measure('middle-to-end', 'middle', 'end');
  performance.measure('start-to-end', 'start', 'end');

  // Get measures
  const measures = performance.getEntriesByType('measure');
  return measures.map(entry => ({
    name: entry.name,
    duration: +entry.duration.toFixed(5)
  }));
}

async function getUserTimingFingerprint() {
  const output = document.getElementById('output');

  const data = {
    measures: collectUserTimingMeasurements()
  };

  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `User Timing Measures:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getUserTimingFingerprint();
