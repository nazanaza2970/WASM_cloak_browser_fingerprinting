async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getWebGPUFingerprint() {
  const output = document.getElementById('output');

  if (!navigator.gpu) {
    output.textContent = 'WebGPU is not supported in this browser.';
    return;
  }

  try {
    const adapter = await navigator.gpu.requestAdapter();
    if (!adapter) {
      output.textContent = 'WebGPU adapter could not be obtained.';
      return;
    }

    const device = await adapter.requestDevice();

    const info = {
      adapter: {
        name: adapter.name,
        features: Array.from(adapter.features || []),
        limits: adapter.limits,
        isFallbackAdapter: (adapter.isFallbackAdapter != null) ? adapter.isFallbackAdapter : null
      },
      device: {
        limits: device.limits
      },
      supportedTextureFormats: (navigator.gpu.getPreferredCanvasFormat
        ? [navigator.gpu.getPreferredCanvasFormat()]
        : [])
    };

    const serialized = JSON.stringify(info);
    const hash = await hashString(serialized);

    output.textContent =
      `WebGPU Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
  } catch (err) {
    output.textContent = `WebGPU Error: ${err.message}`;
  }
}

getWebGPUFingerprint();
