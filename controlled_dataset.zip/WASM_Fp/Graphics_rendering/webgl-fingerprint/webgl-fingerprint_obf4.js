
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

function getWebGLInfo(gl) {
  const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');

  return {
    vendor: debugInfo ? gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) : 'unavailable',
    renderer: debugInfo ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : 'unavailable',
    extensions: gl.getSupportedExtensions().sort(),
    antialias: gl.getContextAttributes().antialias,
    precision: {
      vertex: gl.getShaderPrecisionFormat(gl.VERTEX_SHADER, gl.HIGH_FLOAT),
      fragment: gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER, gl.HIGH_FLOAT)
    }
  };
}

function extractPrecision(prec) {
  return {
    rangeMin: prec.rangeMin,
    rangeMax: prec.rangeMax,
    precision: prec.precision
  };
}

function getWebGLContexts() {
  const canvas = document.createElement('canvas');
  const webgl1 = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
  const webgl2 = canvas.getContext('webgl2');

  const result = {
    webgl1: null,
    webgl2: null
  };

  if (webgl1) {
    const info1 = getWebGLInfo(webgl1);
    result.webgl1 = {
      vendor: info1.vendor,
      renderer: info1.renderer,
      extensions: info1.extensions,
      antialias: info1.antialias,
      precision: {
        vertex: extractPrecision(info1.precision.vertex),
        fragment: extractPrecision(info1.precision.fragment)
      }
    };
  }

  if (webgl2) {
    const info2 = getWebGLInfo(webgl2);
    result.webgl2 = {
      vendor: info2.vendor,
      renderer: info2.renderer,
      extensions: info2.extensions,
      antialias: info2.antialias,
      precision: {
        vertex: extractPrecision(info2.precision.vertex),
        fragment: extractPrecision(info2.precision.fragment)
      }
    };
  }

  return result;
}

async function getWebGLFingerprint() {
  const output = document.getElementById('output');

  const data = getWebGLContexts();
  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `WebGL Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getWebGLFingerprint();
