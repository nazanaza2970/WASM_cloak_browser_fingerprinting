/* svg-fingerprint.js  –  no-DOM-canvas version */

async function hashString(str) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
}

function createSVGContent(svg) {
  svg.innerHTML = `
    <defs>
      <filter id="f1"><feGaussianBlur in="SourceGraphic" stdDeviation="2"/></filter>
    </defs>
    <path d="M10,80 C40,10 65,10 95,80 S150,150 180,80"
          stroke="black" fill="none" stroke-width="2"/>
    <text x="10" y="95" font-family="serif" font-size="18" filter="url(#f1)">
      SVG Fingerprint
    </text>`;
}

async function getSVGFingerprint() {
  const output = document.getElementById("output");
  const svgEl  = document.getElementById("svg");

  /* 1  build the SVG markup */
  createSVGContent(svgEl);
  const svgBlob = new Blob(
    [new XMLSerializer().serializeToString(svgEl)],
    { type: "image/svg+xml" }
  );
  const url = URL.createObjectURL(svgBlob);

  /* 2  rasterise the SVG into an <img> */
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.onload = async () => {
    const { width, height } = img;

    /* 3  create a canvas that never touches the DOM */
    let canvas, ctx;
    if (typeof OffscreenCanvas !== "undefined") {
      canvas = new OffscreenCanvas(width, height);
      ctx    = canvas.getContext("2d");
    } else {
      canvas = document.createElement("canvas");      // still not in the DOM
      canvas.width  = width;
      canvas.height = height;
      ctx    = canvas.getContext("2d");
    }

    ctx.drawImage(img, 0, 0, width, height);
    URL.revokeObjectURL(url);

    /* 4  extract a data URL from either kind of canvas */
    let dataURL;
    if (canvas.convertToBlob) {                // OffscreenCanvas path
      const blob = await canvas.convertToBlob();
      dataURL    = await new Promise(res => {
        const fr = new FileReader();
        fr.onload = () => res(fr.result);
        fr.readAsDataURL(blob);
      });
    } else {                                   // ordinary canvas path
      dataURL = canvas.toDataURL();
    }

    /* 5  hash & display */
    const hash = await hashString(dataURL);
    output.textContent =
      `SVG image hash:\n${hash}\n\nBase64 (truncated):\n${dataURL.slice(0,100)}…`;
  };

  img.onerror = () => { output.textContent = "Error rendering SVG to canvas."; };
  img.src = url;
}

window.addEventListener("DOMContentLoaded", getSVGFingerprint);
