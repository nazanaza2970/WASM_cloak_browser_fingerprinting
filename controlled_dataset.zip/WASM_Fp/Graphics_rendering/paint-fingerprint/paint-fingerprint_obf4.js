
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function getPaintFingerprint() {
  const output = document.getElementById('output');

  if (!('paintWorklet' in CSS)) {
    output.textContent = 'CSS Paint API is not supported.';
    return;
  }

  // Create a blob with the paint worklet code
  const paintCode = `
    registerPaint('fingerprint', class {
      paint(ctx, size, properties) {
        ctx.fillStyle = '#f66';
        ctx.fillRect(0, 0, size.width, size.height);

        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(size.width / 2, size.height / 2, 30, 0, 2 * Math.PI);
        ctx.stroke();
      }
    });
  `;
  const blob = new Blob([paintCode], { type: 'application/javascript' });
  const blobURL = URL.createObjectURL(blob);

  // Load the worklet from the blob URL
  await CSS.paintWorklet.addModule(blobURL);

  // Create and style the element using the paint worklet
  const paintBox = document.getElementById('paint-box');
  paintBox.style.width = '200px';
  paintBox.style.height = '100px';
  paintBox.style.background = 'paint(fingerprint)';

  // Wait for it to render
  await new Promise(res => setTimeout(res, 500));

  const canvas = await html2canvas(paintBox, { useCORS: true });
  const dataURL = canvas.toDataURL();
  const hash = await hashString(dataURL);

  output.textContent =
    `CSS Paint API Image Hash:\n${hash}\n\nData URL (truncated):\n${dataURL.slice(0, 100)}...`;
}

getPaintFingerprint();