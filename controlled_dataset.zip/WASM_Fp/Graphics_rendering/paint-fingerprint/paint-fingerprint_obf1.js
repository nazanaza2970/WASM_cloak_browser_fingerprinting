
let loadWasm = (async function (){
    let wasmBinary_lit = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 4, 5, 1, 112, 1, 1, 1, 5, 3, 1, 0, 1, 6, 156, 2, 47, 127, 0, 65, 32, 11, 127, 0, 65, 192, 0, 11, 127, 0, 65, 224, 0, 11, 127, 0, 65, 128, 1, 11, 127, 0, 65, 160, 1, 11, 127, 0, 65, 192, 1, 11, 127, 0, 65, 224, 1, 11, 127, 0, 65, 128, 2, 11, 127, 0, 65, 160, 2, 11, 127, 0, 65, 192, 2, 11, 127, 0, 65, 224, 2, 11, 127, 0, 65, 128, 3, 11, 127, 0, 65, 160, 3, 11, 127, 0, 65, 192, 3, 11, 127, 0, 65, 224, 3, 11, 127, 0, 65, 144, 4, 11, 127, 0, 65, 192, 4, 11, 127, 0, 65, 224, 4, 11, 127, 0, 65, 128, 5, 11, 127, 0, 65, 176, 5, 11, 127, 0, 65, 224, 5, 11, 127, 0, 65, 128, 6, 11, 127, 0, 65, 160, 6, 11, 127, 0, 65, 192, 6, 11, 127, 0, 65, 224, 3, 11, 127, 0, 65, 144, 4, 11, 127, 0, 65, 224, 6, 11, 127, 0, 65, 128, 7, 11, 127, 0, 65, 160, 7, 11, 127, 0, 65, 192, 7, 11, 127, 0, 65, 224, 7, 11, 127, 0, 65, 128, 8, 11, 127, 0, 65, 160, 7, 11, 127, 0, 65, 192, 7, 11, 127, 0, 65, 160, 8, 11, 127, 0, 65, 192, 8, 11, 127, 0, 65, 160, 7, 11, 127, 0, 65, 192, 7, 11, 127, 0, 65, 224, 8, 11, 127, 0, 65, 128, 9, 11, 127, 0, 65, 192, 4, 11, 127, 0, 65, 224, 4, 11, 127, 0, 65, 160, 9, 11, 127, 0, 65, 192, 9, 11, 127, 0, 65, 204, 9, 11, 127, 1, 65, 204, 137, 2, 11, 127, 0, 65, 204, 137, 2, 11, 7, 180, 4, 45, 9, 118, 97, 114, 95, 49, 53, 48, 95, 49, 3, 0, 9, 118, 97, 114, 95, 49, 53, 48, 95, 50, 3, 1, 9, 118, 97, 114, 95, 49, 52, 51, 95, 49, 3, 2, 9, 118, 97, 114, 95, 49, 52, 51, 95, 50, 3, 3, 9, 118, 97, 114, 95, 50, 48, 49, 95, 49, 3, 4, 9, 118, 97, 114, 95, 50, 48, 49, 95, 50, 3, 5, 9, 118, 97, 114, 95, 50, 57, 54, 95, 49, 3, 6, 9, 118, 97, 114, 95, 50, 57, 54, 95, 50, 3, 7, 9, 118, 97, 114, 95, 50, 55, 56, 95, 49, 3, 8, 9, 118, 97, 114, 95, 50, 55, 56, 95, 50, 3, 9, 9, 118, 97, 114, 95, 50, 54, 53, 95, 49, 3, 10, 9, 118, 97, 114, 95, 50, 54, 53, 95, 50, 3, 11, 9, 118, 97, 114, 95, 50, 53, 52, 95, 49, 3, 12, 9, 118, 97, 114, 95, 50, 53, 52, 95, 50, 3, 13, 9, 118, 97, 114, 95, 51, 55, 52, 95, 49, 3, 14, 9, 118, 97, 114, 95, 51, 55, 52, 95, 50, 3, 15, 9, 118, 97, 114, 95, 52, 52, 54, 95, 49, 3, 16, 9, 118, 97, 114, 95, 52, 52, 54, 95, 50, 3, 17, 10, 118, 97, 114, 95, 49, 48, 52, 48, 95, 49, 3, 18, 10, 118, 97, 114, 95, 49, 48, 52, 48, 95, 50, 3, 19, 10, 118, 97, 114, 95, 49, 49, 50, 57, 95, 49, 3, 20, 10, 118, 97, 114, 95, 49, 49, 50, 57, 95, 50, 3, 21, 10, 118, 97, 114, 95, 49, 49, 49, 54, 95, 49, 3, 22, 10, 118, 97, 114, 95, 49, 49, 49, 54, 95, 50, 3, 23, 10, 118, 97, 114, 95, 49, 50, 51, 54, 95, 49, 3, 24, 10, 118, 97, 114, 95, 49, 50, 51, 54, 95, 50, 3, 25, 10, 118, 97, 114, 95, 49, 50, 56, 50, 95, 49, 3, 26, 10, 118, 97, 114, 95, 49, 50, 56, 50, 95, 50, 3, 27, 10, 118, 97, 114, 95, 49, 50, 55, 54, 95, 49, 3, 28, 10, 118, 97, 114, 95, 49, 50, 55, 54, 95, 50, 3, 29, 10, 118, 97, 114, 95, 49, 51, 49, 54, 95, 49, 3, 30, 10, 118, 97, 114, 95, 49, 51, 49, 54, 95, 50, 3, 31, 10, 118, 97, 114, 95, 49, 51, 49, 48, 95, 49, 3, 32, 10, 118, 97, 114, 95, 49, 51, 49, 48, 95, 50, 3, 33, 10, 118, 97, 114, 95, 49, 51, 53, 49, 95, 49, 3, 34, 10, 118, 97, 114, 95, 49, 51, 53, 49, 95, 50, 3, 35, 10, 118, 97, 114, 95, 49, 51, 52, 53, 95, 49, 3, 36, 10, 118, 97, 114, 95, 49, 51, 52, 53, 95, 50, 3, 37, 10, 118, 97, 114, 95, 49, 53, 53, 53, 95, 49, 3, 38, 10, 118, 97, 114, 95, 49, 53, 53, 53, 95, 50, 3, 39, 10, 118, 97, 114, 95, 49, 54, 50, 48, 95, 49, 3, 40, 10, 118, 97, 114, 95, 49, 54, 50, 48, 95, 50, 3, 41, 10, 118, 97, 114, 95, 49, 55, 49, 48, 95, 49, 3, 42, 10, 118, 97, 114, 95, 49, 55, 49, 48, 95, 50, 3, 43, 6, 109, 101, 109, 111, 114, 121, 2, 0, 9, 6, 1, 0, 65, 1, 11, 0, 12, 1, 36, 11, 151, 11, 36, 0, 65, 12, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 100, 0, 105, 0, 103, 0, 0, 0, 0, 0, 0, 0, 0, 65, 44, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 101, 0, 115, 0, 116, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 0, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 115, 0, 117, 0, 98, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 0, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 116, 0, 108, 0, 101, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 102, 0, 114, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 111, 0, 109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 106, 0, 111, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 1, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 105, 0, 110, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 112, 0, 97, 0, 100, 0, 83, 0, 0, 0, 0, 0, 0, 65, 172, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 116, 0, 97, 0, 114, 0, 116, 0, 0, 0, 0, 0, 0, 65, 204, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 116, 0, 111, 0, 83, 0, 116, 0, 0, 0, 0, 0, 0, 65, 236, 2, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 114, 0, 105, 0, 110, 0, 103, 0, 0, 0, 0, 0, 0, 65, 140, 3, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 3, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 97, 0, 112, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 3, 11, 48, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 14, 0, 0, 0, 103, 0, 101, 0, 116, 0, 69, 0, 108, 0, 101, 0, 109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 252, 3, 11, 48, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 14, 0, 0, 0, 101, 0, 110, 0, 116, 0, 66, 0, 121, 0, 73, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 4, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 10, 0, 0, 0, 116, 0, 101, 0, 120, 0, 116, 0, 67, 0, 0, 0, 0, 65, 204, 4, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 12, 0, 0, 0, 111, 0, 110, 0, 116, 0, 101, 0, 110, 0, 116, 0, 0, 65, 236, 4, 11, 48, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 14, 0, 0, 0, 99, 0, 114, 0, 101, 0, 97, 0, 116, 0, 101, 0, 79, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 156, 5, 11, 48, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 16, 0, 0, 0, 98, 0, 106, 0, 101, 0, 99, 0, 116, 0, 85, 0, 82, 0, 76, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 5, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 97, 0, 100, 0, 100, 0, 77, 0, 0, 0, 0, 0, 0, 65, 236, 5, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 10, 0, 0, 0, 111, 0, 100, 0, 117, 0, 108, 0, 101, 0, 0, 0, 0, 65, 140, 6, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 12, 0, 0, 0, 112, 0, 97, 0, 105, 0, 110, 0, 116, 0, 87, 0, 0, 65, 172, 6, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 12, 0, 0, 0, 111, 0, 114, 0, 107, 0, 108, 0, 101, 0, 116, 0, 0, 65, 204, 6, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 119, 0, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 6, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 100, 0, 116, 0, 104, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 7, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 115, 0, 116, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 7, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 121, 0, 108, 0, 101, 0, 0, 0, 0, 0, 0, 0, 0, 65, 204, 7, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 104, 0, 101, 0, 105, 0, 0, 0, 0, 0, 0, 0, 0, 65, 236, 7, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 103, 0, 104, 0, 116, 0, 0, 0, 0, 0, 0, 0, 0, 65, 140, 8, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 10, 0, 0, 0, 98, 0, 97, 0, 99, 0, 107, 0, 103, 0, 0, 0, 0, 65, 172, 8, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 10, 0, 0, 0, 114, 0, 111, 0, 117, 0, 110, 0, 100, 0, 0, 0, 0, 65, 204, 8, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 8, 0, 0, 0, 116, 0, 111, 0, 68, 0, 97, 0, 0, 0, 0, 0, 0, 65, 236, 8, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 10, 0, 0, 0, 116, 0, 97, 0, 85, 0, 82, 0, 76, 0, 0, 0, 0, 65, 140, 9, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 115, 0, 108, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 172, 9, 11, 32, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 6, 0, 0, 0, 105, 0, 99, 0, 101, 0, 0, 0, 0, 0, 0, 0]);
    const imports =  {env: {
    memory: new WebAssembly.Memory({ initial: 64 }), // Adjust memory size as needed
    __alloc: function (size) {
      // Allocate memory and return a pointer (adjust this function as needed for your runtime)
      return memory_lit.grow(Math.ceil((size + memory_lit.buffer.byteLength) / 65536)) || 0;
    },
    store: function (ptr, value) {
      // Store a value at a memory pointer
      let memoryView = new Int32Array(memory_lit.buffer);
      memoryView[ptr / 4] = value; // Assuming 32-bit integers
    },
    abort: function () {
      console.error("Abort called");
      throw new Error("Abort called");
    },
  },
 };       
    let obj_lit = await WebAssembly.instantiate(wasmBinary_lit,imports); //need to add proper env for func, if-else, loops
    let instance = obj_lit.instance;
    let memory_lit = instance.exports.memory;

    return [instance,memory_lit];
    })();


    loadWasm.then((results)=>{
    let [instance, memory_lit] = results;
    function getString(ptr) {
      let len = new Uint32Array(memory_lit.buffer, ptr - 4, 1)[0];
      let strBuffer = new Uint8Array(memory_lit.buffer, ptr, len);
      let str = '';
      for (let i = 0; i < len; i++) {
        let charCode = strBuffer[i];
        if (charCode !== 0) {  // Skip null characters (if any)
          str += String.fromCharCode(charCode);}
      }
      return str;}

    async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto[getString(instance.exports.var_143_1)+getString(instance.exports.var_143_2)][getString(instance.exports.var_150_1)+getString(instance.exports.var_150_2)]("SHA-256", data);
  const hashArray = Array[getString(instance.exports.var_201_1)+getString(instance.exports.var_201_2)](new Uint8Array(hashBuffer));
  return hashArray[getString(instance.exports.var_254_1)+getString(instance.exports.var_254_2)](b => b[getString(instance.exports.var_265_1)+getString(instance.exports.var_265_2)](16)[getString(instance.exports.var_278_1)+getString(instance.exports.var_278_2)](2, '0'))[getString(instance.exports.var_296_1)+getString(instance.exports.var_296_2)]('');
}

async function getPaintFingerprint() {
  const output = document[getString(instance.exports.var_374_1)+getString(instance.exports.var_374_2)]('output');

  if (!('paintWorklet' in CSS)) {
    output[getString(instance.exports.var_446_1)+getString(instance.exports.var_446_2)] = 'CSS Paint API is not supported.';
    return;
  }

  // Create a blob with the paint worklet code
  const paintCode = `
    registerPaint('fingerprint', class {
      paint(ctx, size, properties) {
        ctx.fillStyle = '#f66';
        ctx.fillRect(0, 0, size.width, size.height);

        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(size.width / 2, size.height / 2, 30, 0, 2 * Math.PI);
        ctx.stroke();
      }
    });
  `;
  const blob = new Blob([paintCode], { type: 'application/javascript' });
  const blobURL = URL[getString(instance.exports.var_1040_1)+getString(instance.exports.var_1040_2)](blob);

  // Load the worklet from the blob URL
  await CSS[getString(instance.exports.var_1116_1)+getString(instance.exports.var_1116_2)][getString(instance.exports.var_1129_1)+getString(instance.exports.var_1129_2)](blobURL);

  // Create and style the element using the paint worklet
  const paintBox = document[getString(instance.exports.var_1236_1)+getString(instance.exports.var_1236_2)]('paint-box');
  paintBox[getString(instance.exports.var_1276_1)+getString(instance.exports.var_1276_2)][getString(instance.exports.var_1282_1)+getString(instance.exports.var_1282_2)] = '200px';
  paintBox[getString(instance.exports.var_1310_1)+getString(instance.exports.var_1310_2)][getString(instance.exports.var_1316_1)+getString(instance.exports.var_1316_2)] = '100px';
  paintBox[getString(instance.exports.var_1345_1)+getString(instance.exports.var_1345_2)][getString(instance.exports.var_1351_1)+getString(instance.exports.var_1351_2)] = 'paint(fingerprint)';

  // Wait for it to render
  await new Promise(res => setTimeout(res, 500));

  const canvas = await html2canvas(paintBox, { useCORS: true });
  const dataURL = canvas[getString(instance.exports.var_1555_1)+getString(instance.exports.var_1555_2)]();
  const hash = await hashString(dataURL);

  output[getString(instance.exports.var_1620_1)+getString(instance.exports.var_1620_2)] =
    `CSS Paint API Image Hash:\n${hash}\n\nData URL (truncated):\n${dataURL[getString(instance.exports.var_1710_1)+getString(instance.exports.var_1710_2)](0, 100)}...`;
}

getPaintFingerprint();
    });
    