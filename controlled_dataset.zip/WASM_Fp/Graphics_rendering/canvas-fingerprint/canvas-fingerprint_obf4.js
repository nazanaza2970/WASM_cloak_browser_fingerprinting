
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

function drawCanvasContent(canvas) {
  const ctx = canvas.getContext('2d');

  ctx.textBaseline = "top";
  ctx.font = "16px 'Arial'";
  ctx.fillStyle = "#f60";
  ctx.fillRect(0, 0, 300, 100);

  ctx.fillStyle = "#069";
  ctx.fillText("C@nvas Fingerprint", 10, 10);

  ctx.strokeStyle = "rgba(102, 204, 0, 0.8)";
  ctx.strokeText("C@nvas Fingerprint", 10, 10);

  ctx.beginPath();
  ctx.arc(150, 50, 30, 0, Math.PI * 2);
  ctx.stroke();
}

async function getCanvasFingerprint() {
  const output = document.getElementById('output');
  const canvas = document.createElement('canvas');
  canvas.width = 200;
  canvas.height = 50;

  drawCanvasContent(canvas);

  const dataURL = canvas.toDataURL(); // base64-encoded image
  const hash = await hashString(dataURL);

  output.textContent =
    `Canvas Data URL (truncated):\n${dataURL.slice(0, 100)}...\n\nSHA-256 Fingerprint:\n${hash}`;
}

getCanvasFingerprint();
