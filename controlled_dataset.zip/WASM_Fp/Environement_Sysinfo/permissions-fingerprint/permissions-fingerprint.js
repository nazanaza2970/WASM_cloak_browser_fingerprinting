async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getPermissionsFingerprint() {
  const output = document.getElementById('output');

  if (!navigator.permissions || !navigator.permissions.query) {
    output.textContent = 'Permissions API not supported in this browser.';
    return;
  }

  const permissionsToCheck = [
    'geolocation',
    'notifications',
    'camera',
    'microphone',
    'clipboard-read',
    'clipboard-write',
    'background-sync',
    'persistent-storage',
    'accelerometer',
    'gyroscope',
    'magnetometer',
    'midi'
  ];

  const results = {};

  for (const name of permissionsToCheck) {
    try {
      const status = await navigator.permissions.query({ name });
      results[name] = status.state;
    } catch (err) {
      results[name] = 'unsupported';
    }
  }

  const serialized = JSON.stringify(results);
  const hash = await hashString(serialized);

  output.textContent =
    `Permissions Status:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getPermissionsFingerprint();
