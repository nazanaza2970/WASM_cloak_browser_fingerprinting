
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function getPermissionsFingerprint() {
  const output = document.getElementById('output');

  if (!navigator.permissions || !navigator.permissions.query) {
    output.textContent = 'Permissions API not supported in this browser.';
    return;
  }

  const permissionsToCheck = [
    'geolocation',
    'notifications',
    'camera',
    'microphone',
    'clipboard-read',
    'clipboard-write',
    'background-sync',
    'persistent-storage',
    'accelerometer',
    'gyroscope',
    'magnetometer',
    'midi'
  ];

  const results = {};

  for (const name of permissionsToCheck) {
    try {
      const status = await navigator.permissions.query({ name });
      results[name] = status.state;
    } catch (err) {
      results[name] = 'unsupported';
    }
  }

  const serialized = JSON.stringify(results);
  const hash = await hashString(serialized);

  output.textContent =
    `Permissions Status:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getPermissionsFingerprint();
