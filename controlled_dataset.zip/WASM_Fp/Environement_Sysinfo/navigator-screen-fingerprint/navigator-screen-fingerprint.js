async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getNavigatorScreenFingerprint() {
  const data = {
    userAgent: navigator.userAgent,
    deviceMemory: navigator.deviceMemory || 'unsupported',
    hardwareConcurrency: navigator.hardwareConcurrency || 'unsupported',
    screen: {
      width: screen.width,
      height: screen.height,
      availWidth: screen.availWidth,
      availHeight: screen.availHeight,
      colorDepth: screen.colorDepth,
      pixelDepth: screen.pixelDepth,
    }
  };

  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  document.getElementById('output').textContent =
    `Collected Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getNavigatorScreenFingerprint();
