
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function getNavigatorScreenFingerprint() {
  const data = {
    userAgent: navigator.userAgent,
    deviceMemory: navigator.deviceMemory || 'unsupported',
    hardwareConcurrency: navigator.hardwareConcurrency || 'unsupported',
    screen: {
      width: screen.width,
      height: screen.height,
      availWidth: screen.availWidth,
      availHeight: screen.availHeight,
      colorDepth: screen.colorDepth,
      pixelDepth: screen.pixelDepth,
    }
  };

  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  document.getElementById('output').textContent =
    `Collected Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getNavigatorScreenFingerprint();
