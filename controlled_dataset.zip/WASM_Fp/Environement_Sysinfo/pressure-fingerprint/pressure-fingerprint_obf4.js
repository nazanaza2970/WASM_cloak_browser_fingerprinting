// The Compute Pressure API is experimental, only available in Chromium-based browsers (like Chrome/Edge).

// Requires HTTPS and may need chrome://flags to enable "Compute Pressure API".

// It does not give exact values, but returns hints like "nominal", "fair", "serious", "critical".


import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

window.getComputePressureFingerprint = async function() {
  const output = document.getElementById('output');

  if (!navigator.computePressure || !navigator.computePressure.watch) {
    output.textContent = 'Compute Pressure API is not supported in this browser.';
    return;
  }

  try {
    const readings = [];

    const observer = await navigator.computePressure.watch(
      (update) => {
        readings.push(update);
        if (readings.length >= 1) {
          // Stop after first reading (or could collect multiple over time)
          observer.stop();

          const serialized = JSON.stringify(readings);
          hashString(serialized).then(hash => {
            output.textContent =
              `Compute Pressure Readings:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
          });
        }
      },
      { sampleRate: 1 } // sample once per second
    );
  } catch (err) {
    output.textContent = `Compute Pressure API error: ${err.message}`;
  }
}

getComputePressureFingerprint();
