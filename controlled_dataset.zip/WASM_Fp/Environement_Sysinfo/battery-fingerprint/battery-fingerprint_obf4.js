
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function getBatteryFingerprint() {
  const output = document.getElementById('output');

  if (!navigator.getBattery) {
    output.textContent = 'Battery API not supported in this browser.';
    return;
  }

  try {
    const battery = await navigator.getBattery();
    const data = {
      charging: battery.charging,
      chargingTime: battery.chargingTime,
      dischargingTime: battery.dischargingTime,
      level: battery.level
    };

    const serialized = JSON.stringify(data);
    const hash = await hashString(serialized);

    output.textContent =
      `Collected Battery Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
  } catch (err) {
    output.textContent = `Battery API error: ${err.message}`;
  }
}

getBatteryFingerprint();
