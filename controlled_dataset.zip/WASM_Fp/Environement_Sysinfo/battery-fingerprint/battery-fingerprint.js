async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getBatteryFingerprint() {
  const output = document.getElementById('output');

  if (!navigator.getBattery) {
    output.textContent = 'Battery API not supported in this browser.';
    return;
  }

  try {
    const battery = await navigator.getBattery();
    const data = {
      charging: battery.charging,
      chargingTime: battery.chargingTime,
      dischargingTime: battery.dischargingTime,
      level: battery.level
    };

    const serialized = JSON.stringify(data);
    const hash = await hashString(serialized);

    output.textContent =
      `Collected Battery Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
  } catch (err) {
    output.textContent = `Battery API error: ${err.message}`;
  }
}

getBatteryFingerprint();
