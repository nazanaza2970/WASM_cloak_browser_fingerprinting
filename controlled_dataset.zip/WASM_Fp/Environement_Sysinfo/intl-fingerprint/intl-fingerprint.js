async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getIntlFingerprint() {
  const output = document.getElementById('output');
  const data = {};

  try {
    // Intl.DateTimeFormat
    data.dateTimeFormat = Intl.DateTimeFormat().resolvedOptions();

    // Intl.DisplayNames
    const langNames = new Intl.DisplayNames(['en'], { type: 'language' });
    const regionNames = new Intl.DisplayNames(['en'], { type: 'region' });

    data.displayNames = {
      language: langNames.of('fr'),     // French
      region: regionNames.of('DE'),     // Germany
    };

    // Serialize and hash
    const serialized = JSON.stringify(data);
    const hash = await hashString(serialized);

    output.textContent =
      `Collected Intl Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
  } catch (err) {
    output.textContent = `Intl API error: ${err.message}`;
  }
}

getIntlFingerprint();
