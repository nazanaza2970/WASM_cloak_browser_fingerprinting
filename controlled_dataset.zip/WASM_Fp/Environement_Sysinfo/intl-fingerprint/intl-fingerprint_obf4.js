
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function getIntlFingerprint() {
  const output = document.getElementById('output');
  const data = {};

  try {
    // Intl.DateTimeFormat
    data.dateTimeFormat = Intl.DateTimeFormat().resolvedOptions();

    // Intl.DisplayNames
    const langNames = new Intl.DisplayNames(['en'], { type: 'language' });
    const regionNames = new Intl.DisplayNames(['en'], { type: 'region' });

    data.displayNames = {
      language: langNames.of('fr'),     // French
      region: regionNames.of('DE'),     // Germany
    };

    // Serialize and hash
    const serialized = JSON.stringify(data);
    const hash = await hashString(serialized);

    output.textContent =
      `Collected Intl Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
  } catch (err) {
    output.textContent = `Intl API error: ${err.message}`;
  }
}

getIntlFingerprint();
