
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

function highResTimingProbe() {
  const sab = new SharedArrayBuffer(4);
  const arr = new Int32Array(sab);

  const iterations = 1000;
  const deltas = [];

  for (let i = 0; i < iterations; i++) {
    const t1 = performance.now();
    Atomics.add(arr, 0, 0); // Simple atomic operation
    const t2 = performance.now();
    deltas.push(+(t2 - t1).toFixed(6));
  }

  return deltas;
}

async function getSABFingerprint() {
  const output = document.getElementById('output');
  const metadata = {
    sabSupported: false,
    timingSamples: [],
    error: null
  };

  try {
    if (typeof SharedArrayBuffer === 'undefined') {
      metadata.error = 'SharedArrayBuffer not supported';
    } else {
      metadata.sabSupported = true;
      metadata.timingSamples = highResTimingProbe();
    }
  } catch (e) {
    metadata.error = e.message;
  }

  const serialized = JSON.stringify(metadata);
  const hash = await hashString(serialized);

  output.textContent =
    `SharedArrayBuffer/Atomics Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getSABFingerprint();
