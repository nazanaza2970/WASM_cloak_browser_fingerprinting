async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function getAllStorage(storage) {
  const obj = {};
  for (let i = 0; i < storage.length; i++) {
    const key = storage.key(i);
    obj[key] = storage.getItem(key);
  }
  return obj;
}

async function getStorageFingerprint() {
  const output = document.getElementById('output');

  const data = {
    cookies: document.cookie || '',
    localStorage: getAllStorage(localStorage),
    sessionStorage: getAllStorage(sessionStorage)
  };

  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `Collected Storage Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getStorageFingerprint();
