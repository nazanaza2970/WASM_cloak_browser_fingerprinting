async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function openTestIndexedDB() {
  return new Promise((resolve, reject) => {
    const dbName = 'fpTestDB';
    const version = 1;
    const request = indexedDB.open(dbName, version);

    let metadata = {
      dbName,
      version,
      objectStoreName: 'metaStore',
      success: false,
      error: null
    };

    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      try {
        db.createObjectStore(metadata.objectStoreName, { keyPath: 'id' });
      } catch (e) {
        metadata.error = `Create store failed: ${e.message}`;
      }
    };

    request.onsuccess = (event) => {
      metadata.success = true;
      const db = event.target.result;

      // Try writing and reading one item
      const tx = db.transaction(metadata.objectStoreName, 'readwrite');
      const store = tx.objectStore(metadata.objectStoreName);
      store.put({ id: 1, value: 'test' });

      tx.oncomplete = () => {
        // Try reading back the item
        const readTx = db.transaction(metadata.objectStoreName, 'readonly');
        const readStore = readTx.objectStore(metadata.objectStoreName);
        const getReq = readStore.get(1);
        getReq.onsuccess = () => {
          metadata.readValue = (getReq.result && getReq.result.value) || null;
          db.close();
          indexedDB.deleteDatabase(dbName); // Clean up
          resolve(metadata);
        };
        getReq.onerror = () => {
          metadata.readValue = 'read-fail';
          db.close();
          resolve(metadata);
        };
      };

      tx.onerror = () => {
        metadata.error = 'write-fail';
        db.close();
        resolve(metadata);
      };
    };

    request.onerror = () => {
      metadata.success = false;
      metadata.error = (request.error && request.error.message) || 'unknown';
      resolve(metadata);
    };
  });
}

async function getIndexedDBFingerprint() {
  const output = document.getElementById('output');

  const result = await openTestIndexedDB();
  const serialized = JSON.stringify(result);
  const hash = await hashString(serialized);

  output.textContent =
    `IndexedDB Result:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getIndexedDBFingerprint();
