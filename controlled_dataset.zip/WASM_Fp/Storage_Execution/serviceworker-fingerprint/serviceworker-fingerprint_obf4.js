
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function getServiceWorkerFingerprint() {
  const output = document.getElementById('output');

  const metadata = {
    supported: false,
    registrationSuccess: false,
    scriptURL: null,
    scope: null,
    installTime: null,
    error: null
  };

  if (!('serviceWorker' in navigator)) {
    output.textContent = 'Service Workers not supported in this browser.';
    return;
  }

  metadata.supported = true;
  const start = performance.now();

  try {
    const registration = await navigator.serviceWorker.register('/sw.js', { scope: './' });
    const end = performance.now();

    metadata.registrationSuccess = true;
    metadata.scriptURL = registration.scriptURL;
    metadata.scope = registration.scope;
    metadata.installTime = +(end - start).toFixed(3);

    // Optionally unregister to clean up
    registration.unregister();
  } catch (err) {
    metadata.error = err.message;
  }

  const serialized = JSON.stringify(metadata);
  const hash = await hashString(serialized);

  output.textContent =
    `Service Worker Metadata:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getServiceWorkerFingerprint();
