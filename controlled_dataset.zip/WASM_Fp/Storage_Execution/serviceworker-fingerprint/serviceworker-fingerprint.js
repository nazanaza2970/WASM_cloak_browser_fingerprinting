async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getServiceWorkerFingerprint() {
  const output = document.getElementById('output');

  const metadata = {
    supported: false,
    registrationSuccess: false,
    scriptURL: null,
    scope: null,
    installTime: null,
    error: null
  };

  if (!('serviceWorker' in navigator)) {
    output.textContent = 'Service Workers not supported in this browser.';
    return;
  }

  metadata.supported = true;
  const start = performance.now();

  try {
    const registration = await navigator.serviceWorker.register('/sw.js', { scope: './' });
    const end = performance.now();

    metadata.registrationSuccess = true;
    metadata.scriptURL = registration.scriptURL;
    metadata.scope = registration.scope;
    metadata.installTime = +(end - start).toFixed(3);

    // Optionally unregister to clean up
    registration.unregister();
  } catch (err) {
    metadata.error = err.message;
  }

  const serialized = JSON.stringify(metadata);
  const hash = await hashString(serialized);

  output.textContent =
    `Service Worker Metadata:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getServiceWorkerFingerprint();
