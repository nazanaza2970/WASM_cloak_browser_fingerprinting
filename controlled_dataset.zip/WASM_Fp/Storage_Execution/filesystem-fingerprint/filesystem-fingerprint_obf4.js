
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function testFileSystemFingerprint() {
  const output = document.getElementById('output');
  const metadata = {
    supported: false,
    userCanceled: false,
    fileTypesRespected: null,
    fileCount: 0,
    fileNameSample: null
  };

  if (!window.showOpenFilePicker) {
    output.textContent = 'File System Access API not supported in this browser.';
    return;
  }

  metadata.supported = true;

  try {
    const start = performance.now();
    const handles = await showOpenFilePicker({
      multiple: true,
      types: [{
        description: 'Text files only',
        accept: { 'text/plain': ['.txt'] }
      }]
    });
    const end = performance.now();

    metadata.interactionTime = +(end - start).toFixed(3);
    metadata.fileCount = handles.length;
    metadata.fileNameSample = (handles[0] && handles[0].name) || null;

    // Check if the user selected non-txt despite filter
    metadata.fileTypesRespected = handles.every(h => h.name.endsWith('.txt'));

  } catch (err) {
    if (err.name === 'AbortError') {
      metadata.userCanceled = true;
    } else {
      metadata.error = err.message;
    }
  }

  const serialized = JSON.stringify(metadata);
  const hash = await hashString(serialized);

  output.textContent =
    `File System Metadata:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

document.getElementById('trigger').addEventListener('click', testFileSystemFingerprint);
