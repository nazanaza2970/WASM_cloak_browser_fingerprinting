async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function round(v) {
  return v !== null && v !== undefined ? +v.toFixed(4) : null;
}

function startMotionFingerprinting() {
  const output = document.getElementById('output');
  const samples = {
    orientation: [],
    motion: []
  };

  let count = 0;
  const maxSamples = 20;

  function handleOrientation(e) {
    if (count >= maxSamples) return;
    samples.orientation.push({
      alpha: round(e.alpha),
      beta: round(e.beta),
      gamma: round(e.gamma)
    });
  }

  function handleMotion(e) {
    if (count >= maxSamples) return;

    samples.motion.push({
      acc: {
        x: (e.acceleration && e.acceleration.x) !== undefined ? round(e.acceleration.x) : undefined,
        y: (e.acceleration && e.acceleration.y) !== undefined ? round(e.acceleration.y) : undefined,
        z: (e.acceleration && e.acceleration.z) !== undefined ? round(e.acceleration.z) : undefined
      },
      rot: {
        alpha: (e.rotationRate && e.rotationRate.alpha) !== undefined ? round(e.rotationRate.alpha) : undefined,
        beta: (e.rotationRate && e.rotationRate.beta) !== undefined ? round(e.rotationRate.beta) : undefined,
        gamma: (e.rotationRate && e.rotationRate.gamma) !== undefined ? round(e.rotationRate.gamma) : undefined
      }
    });

    count++;

    if (count >= maxSamples) {
      window.removeEventListener("deviceorientation", handleOrientation);
      window.removeEventListener("devicemotion", handleMotion);
      processAndHash(samples);
    }
}


  window.addEventListener("deviceorientation", handleOrientation, true);
  window.addEventListener("devicemotion", handleMotion, true);
}

async function processAndHash(data) {
  const output = document.getElementById('output');
  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `Device Motion & Orientation Samples:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

document.getElementById('start').addEventListener('click', () => {
  if (DeviceMotionEvent && typeof DeviceMotionEvent.requestPermission === 'function') {
    // iOS 13+ requires explicit permission
    DeviceMotionEvent.requestPermission().then(permissionState => {
      if (permissionState === 'granted') startMotionFingerprinting();
      else document.getElementById('output').textContent = 'Permission denied.';
    });
  } else {
    startMotionFingerprinting();
  }
});
