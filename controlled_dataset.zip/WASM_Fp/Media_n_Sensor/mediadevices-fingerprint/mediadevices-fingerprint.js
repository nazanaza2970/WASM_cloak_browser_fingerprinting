async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getMediaFingerprint() {
  const output = document.getElementById('output');

  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    output.textContent = 'MediaDevices API is not supported in this browser.';
    return;
  }

  try {
    // Ask for minimal access (will trigger a permission prompt)
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });

    // Stop all tracks immediately (no recording)
    stream.getTracks().forEach(track => track.stop());

    const devices = await navigator.mediaDevices.enumerateDevices();
    const constraints = navigator.mediaDevices.getSupportedConstraints();

    const metadata = {
      devices: devices.map(d => ({
        kind: d.kind,
        label: d.label,
        deviceId: d.deviceId,
        groupId: d.groupId
      })),
      supportedConstraints: constraints
    };

    const serialized = JSON.stringify(metadata);
    const hash = await hashString(serialized);

    output.textContent =
      `Collected MediaDevices Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
  } catch (err) {
    output.textContent = `Error accessing media devices: ${err.message}`;
  }
}

document.getElementById('start').addEventListener('click', getMediaFingerprint);
