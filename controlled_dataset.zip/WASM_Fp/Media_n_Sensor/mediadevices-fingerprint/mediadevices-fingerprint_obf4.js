
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function getMediaFingerprint() {
  const output = document.getElementById('output');

  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    output.textContent = 'MediaDevices API is not supported in this browser.';
    return;
  }

  try {
    // Ask for minimal access (will trigger a permission prompt)
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });

    // Stop all tracks immediately (no recording)
    stream.getTracks().forEach(track => track.stop());

    const devices = await navigator.mediaDevices.enumerateDevices();
    const constraints = navigator.mediaDevices.getSupportedConstraints();

    const metadata = {
      devices: devices.map(d => ({
        kind: d.kind,
        label: d.label,
        deviceId: d.deviceId,
        groupId: d.groupId
      })),
      supportedConstraints: constraints
    };

    const serialized = JSON.stringify(metadata);
    const hash = await hashString(serialized);

    output.textContent =
      `Collected MediaDevices Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
  } catch (err) {
    output.textContent = `Error accessing media devices: ${err.message}`;
  }
}

document.getElementById('start').addEventListener('click', getMediaFingerprint);
