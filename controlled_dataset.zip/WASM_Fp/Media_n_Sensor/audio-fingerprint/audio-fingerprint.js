async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getAudioFingerprint() {
  const output = document.getElementById('output');

  if (!window.OfflineAudioContext && !window.webkitOfflineAudioContext) {
    output.textContent = 'OfflineAudioContext not supported.';
    return;
  }

  const OfflineCtx = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  const context = new OfflineCtx(1, 44100, 44100); // mono, 1 sec, 44.1kHz

  const oscillator = context.createOscillator();
  const compressor = context.createDynamicsCompressor();

  // Oscillator settings (sine wave fingerprint)
  oscillator.type = "triangle";
  oscillator.frequency.value = 1000;

  // Compressor settings (adds more entropy)
  compressor.threshold.value = -50;
  compressor.knee.value = 40;
  compressor.ratio.value = 12;
  compressor.attack.value = 0;
  compressor.release.value = 0.25;

  oscillator.connect(compressor);
  compressor.connect(context.destination);
  oscillator.start(0);

  const rendered = await context.startRendering();

  const samples = rendered.getChannelData(0).slice(0, 100); // first 100 samples
  const serialized = JSON.stringify(Array.from(samples.map(x => +x.toFixed(6))));
  const hash = await hashString(serialized);

  output.textContent =
    `First 100 samples:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getAudioFingerprint();
