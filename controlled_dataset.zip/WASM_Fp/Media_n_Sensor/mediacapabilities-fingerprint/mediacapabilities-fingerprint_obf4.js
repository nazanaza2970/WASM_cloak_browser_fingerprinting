
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

async function getMediaCapabilitiesFingerprint() {
  const output = document.getElementById('output');

  if (!navigator.mediaCapabilities) {
    output.textContent = 'MediaCapabilities API not supported in this browser.';
    return;
  }

  const fingerprintData = {
    decoding: [],
    encoding: []
  };

  const videoConfigs = [
    {
      type: "file",
      video: {
        contentType: "video/webm; codecs=vp8",
        width: 1920,
        height: 1080,
        bitrate: 1000000,
        framerate: 30
      }
    },
    {
      type: "file",
      video: {
        contentType: "video/mp4; codecs=avc1.42E01E",
        width: 1280,
        height: 720,
        bitrate: 800000,
        framerate: 30
      }
    }
  ];

  const audioConfigs = [
    {
      type: "file",
      audio: {
        contentType: "audio/webm; codecs=opus",
        channels: 2,
        bitrate: 128000,
        samplerate: 48000
      }
    },
    {
      type: "file",
      audio: {
        contentType: "audio/mp4; codecs=mp4a.40.2",
        channels: 2,
        bitrate: 96000,
        samplerate: 44100
      }
    }
  ];

  for (const config of videoConfigs) {
    try {
      const result = await navigator.mediaCapabilities.decodingInfo(config);
      fingerprintData.decoding.push({
        config: config.video.contentType,
        supported: result.supported,
        smooth: result.smooth,
        powerEfficient: result.powerEfficient
      });
    } catch (e) {
      fingerprintData.decoding.push({ config: config.video.contentType, error: e.message });
    }
  }

  for (const config of audioConfigs) {
    try {
      const result = await navigator.mediaCapabilities.encodingInfo(config);
      fingerprintData.encoding.push({
        config: config.audio.contentType,
        supported: result.supported
      });
    } catch (e) {
      fingerprintData.encoding.push({ config: config.audio.contentType, error: e.message });
    }
  }

  const serialized = JSON.stringify(fingerprintData);
  const hash = await hashString(serialized);

  output.textContent =
    `Media Capabilities:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getMediaCapabilitiesFingerprint();
