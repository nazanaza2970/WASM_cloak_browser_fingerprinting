
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

function round(val) {
  return val !== undefined ? +val.toFixed(4) : null;
}

function collectSensorReading(SensorClass, fields) {
  return new Promise((resolve) => {
    if (typeof SensorClass !== 'function') return resolve('unsupported');

    try {
      const sensor = new SensorClass({ frequency: 1 });
      const timeout = setTimeout(() => {
        sensor.stop();
        resolve('timeout');
      }, 1000);

      sensor.addEventListener('reading', () => {
        clearTimeout(timeout);
        const result = {};
        for (const f of fields) result[f] = round(sensor[f]);
        sensor.stop();
        resolve(result);
      });

      sensor.addEventListener('error', e => {
        clearTimeout(timeout);
        resolve('error:' + (e.error && e.error.name || 'unknown'));
      });

      sensor.start();
    } catch (e) {
      resolve('init-error:' + e.message);
    }
  });
}

async function getSensorFingerprint() {
  const output = document.getElementById('output');
  output.textContent = 'Collecting sensor data...';

  const results = {
    ambientLight: await collectSensorReading(window.AmbientLightSensor, ['illuminance']),
    proximity: await collectSensorReading(window.ProximitySensor, ['distance', 'near', 'max']),
    magnetometer: await collectSensorReading(window.Magnetometer, ['x', 'y', 'z'])
  };

  const serialized = JSON.stringify(results);
  const hash = await hashString(serialized);

  output.textContent =
    `Sensor Readings:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

document.getElementById('start').addEventListener('click', getSensorFingerprint);
