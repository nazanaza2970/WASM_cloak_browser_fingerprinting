async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function setupKeyboardCapture() {
  const area = document.getElementById('keyboardArea');
  const output = document.getElementById('output');

  const keyTimings = {};
  const results = [];

  area.addEventListener('keydown', e => {
    if (!keyTimings[e.code]) {
      keyTimings[e.code] = performance.now();
    }
  });

  area.addEventListener('keyup', e => {
    const now = performance.now();
    if (keyTimings[e.code]) {
      const downTime = keyTimings[e.code];
      const latency = +(now - downTime).toFixed(3);

      results.push({
        key: e.key,
        code: e.code,
        latency
      });

      delete keyTimings[e.code];

      if (results.length >= 10) {
        area.disabled = true;
        generateFingerprint(results);
      }
    }
  });
}

async function generateFingerprint(results) {
  const output = document.getElementById('output');
  const serialized = JSON.stringify(results);
  const hash = await hashString(serialized);

  output.textContent =
    `Keyboard Event Data:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

setupKeyboardCapture();
