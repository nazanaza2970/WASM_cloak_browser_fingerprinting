async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function round(val) {
  return +val.toFixed(4);
}

function collectPointerData() {
  return new Promise(resolve => {
    const box = document.getElementById('box');
    const coords = {
      pointermove: [],
      mousemove: [],
      touchstart: []
    };

    const cleanup = () => {
      box.removeEventListener('pointermove', onPointerMove);
      box.removeEventListener('mousemove', onMouseMove);
      box.removeEventListener('touchstart', onTouchStart);
    };

    const onPointerMove = e => {
      coords.pointermove.push([round(e.clientX), round(e.clientY), e.pointerType]);
      if (coords.pointermove.length >= 10) {
        cleanup();
        resolve(coords);
      }
    };

    const onMouseMove = e => {
      coords.mousemove.push([round(e.clientX), round(e.clientY)]);
    };

    const onTouchStart = e => {
      for (const t of e.touches) {
        coords.touchstart.push([round(t.clientX), round(t.clientY), round(t.radiusX), round(t.radiusY)]);
      }
    };

    box.addEventListener('pointermove', onPointerMove);
    box.addEventListener('mousemove', onMouseMove);
    box.addEventListener('touchstart', onTouchStart);
  });
}

async function getPointerFingerprint() {
  const output = document.getElementById('output');

  const coords = await collectPointerData();
  const serialized = JSON.stringify(coords);
  const hash = await hashString(serialized);

  output.textContent =
    `Pointer Event Data:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getPointerFingerprint();
