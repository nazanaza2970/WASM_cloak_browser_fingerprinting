
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

function round(val) {
  return +val.toFixed(4);
}

function collectPointerData() {
  return new Promise(resolve => {
    const box = document.getElementById('box');
    const coords = {
      pointermove: [],
      mousemove: [],
      touchstart: []
    };

    const cleanup = () => {
      box.removeEventListener('pointermove', onPointerMove);
      box.removeEventListener('mousemove', onMouseMove);
      box.removeEventListener('touchstart', onTouchStart);
    };

    const onPointerMove = e => {
      coords.pointermove.push([round(e.clientX), round(e.clientY), e.pointerType]);
      if (coords.pointermove.length >= 10) {
        cleanup();
        resolve(coords);
      }
    };

    const onMouseMove = e => {
      coords.mousemove.push([round(e.clientX), round(e.clientY)]);
    };

    const onTouchStart = e => {
      for (const t of e.touches) {
        coords.touchstart.push([round(t.clientX), round(t.clientY), round(t.radiusX), round(t.radiusY)]);
      }
    };

    box.addEventListener('pointermove', onPointerMove);
    box.addEventListener('mousemove', onMouseMove);
    box.addEventListener('touchstart', onTouchStart);
  });
}

async function getPointerFingerprint() {
  const output = document.getElementById('output');

  const coords = await collectPointerData();
  const serialized = JSON.stringify(coords);
  const hash = await hashString(serialized);

  output.textContent =
    `Pointer Event Data:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getPointerFingerprint();
