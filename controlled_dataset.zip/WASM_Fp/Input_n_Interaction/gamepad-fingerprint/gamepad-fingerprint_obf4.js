
import {sha256} from 'https://cdn.jsdelivr.net/npm/hash-wasm@4.12.0/+esm';

async function hashString(some_str){

const hash = await sha256(some_str);
return hash;
};
    

function getGamepadSnapshot() {
  const pads = navigator.getGamepads();
  const snapshot = [];

  for (const pad of pads) {
    if (!pad) continue;
    snapshot.push({
      id: pad.id,
      index: pad.index,
      mapping: pad.mapping,
      connected: pad.connected,
      buttons: pad.buttons.length,
      axes: pad.axes.length,
      timestamp: pad.timestamp
    });
  }

  return snapshot;
}

async function getGamepadFingerprint() {
  const output = document.getElementById('output');

  // Wait a moment in case the user is just connecting or activating the gamepad
  await new Promise(res => setTimeout(res, 2000));

  const data = getGamepadSnapshot();
  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `Gamepad Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getGamepadFingerprint();
