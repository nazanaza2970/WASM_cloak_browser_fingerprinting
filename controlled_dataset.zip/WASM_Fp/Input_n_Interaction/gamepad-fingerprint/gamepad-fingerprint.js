async function hashString(input) {
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function getGamepadSnapshot() {
  const pads = navigator.getGamepads();
  const snapshot = [];

  for (const pad of pads) {
    if (!pad) continue;
    snapshot.push({
      id: pad.id,
      index: pad.index,
      mapping: pad.mapping,
      connected: pad.connected,
      buttons: pad.buttons.length,
      axes: pad.axes.length,
      timestamp: pad.timestamp
    });
  }

  return snapshot;
}

async function getGamepadFingerprint() {
  const output = document.getElementById('output');

  // Wait a moment in case the user is just connecting or activating the gamepad
  await new Promise(res => setTimeout(res, 2000));

  const data = getGamepadSnapshot();
  const serialized = JSON.stringify(data);
  const hash = await hashString(serialized);

  output.textContent =
    `Gamepad Info:\n${serialized}\n\nSHA-256 Fingerprint:\n${hash}`;
}

getGamepadFingerprint();
