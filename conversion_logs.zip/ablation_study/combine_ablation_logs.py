from pathlib import Path
import pandas as pd
import re
import math
from tqdm import tqdm

def generate_report(folder: str | Path) -> pd.DataFrame:
    folder = Path(folder)
    rows = []

    for csv_file in tqdm(folder.glob("conversion_log_*.csv")):
        rule_name = re.sub(r"^conversion_log_", "", csv_file.stem)

        df = pd.read_csv(csv_file)

        # Attempted = rows whose `working_rules` cell is non-blank
        # attempted_mask = df["working_rules"].notna() & (df["working_rules"].astype(str).str.strip() != "")
        attempted_mask = (df["large_file_skip"] == 0) & (df["ast_fail"] == 0)
        attempted = attempted_mask.sum()

        if attempted:
            # success_rows = df.loc[ (df["success"] == 1)]
            success_rows = df.loc[attempted_mask & (df["success"] == 1)]
            success_rate = round(100 * len(success_rows) / attempted, 2)

            # conv_pct = df["cnv_ptg"].mean()
            conv_pct = df.loc[attempted_mask, "cnv_ptg"].mean()
            conv_pct = 0.0 if math.isnan(conv_pct) else round(conv_pct, 4)

            # avg_conv_time = df["time_cnv"].mean()
            avg_conv_time = df.loc[attempted_mask, "time_cnv"].mean()
            avg_conv_time = 0.0 if math.isnan(avg_conv_time) else round(avg_conv_time, 4)

            # avg_val_time = df["time_val"].mean()
            avg_val_time = df.loc[attempted_mask, "time_val"].mean()
            avg_val_time = 0.0 if math.isnan(avg_val_time) else round(avg_val_time, 4)
        else:
            success_rate = conv_pct = avg_val_time = 0.0

        rows.append(
            {
                "rule": rule_name,
                "attempted": attempted,
                "success_rate(%)": success_rate,
                "conversion_percentage": conv_pct,
                "average_conversion_time(s)": avg_conv_time,
                "average_validation_time(s)": avg_val_time,
                "size_difference": "",  # placeholder
            }
        )

    report_df = pd.DataFrame(rows)
    report_df.to_csv(folder / "conversion_report.csv", index=False)
    print(f"Report saved to {folder/'conversion_report.csv'}")
    return report_df

if __name__ == "__main__":
    # Change "." if the logs live elsewhere
    generate_report(".")
